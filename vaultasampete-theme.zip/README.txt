VAULTASAMPETE SHOPIFY THEME: SETUP

UPLOAD
1. Shopify admin > Online Store > Themes > Add theme > Upload zip file.
2. Open Customize. Edit text on the Hero, Studio, Vault, The hand and Keys sections.
3. Preview in your store before publishing. This theme was validated for structure
   but not tested inside a live Shopify store.

PRODUCT SETUP (drives the cards, stickers and filters)
- Product type: use exactly  Art  /  Design  /  Vintage   (sets the filter and plate style)
- Tags:  one-of-one   on-hold   re-entered   (sets the status sticker; sold out also shows Re-entered)
- Inventory: set to 1 and turn OFF "continue selling when out of stock"
- SKU: your vault number, e.g. VS-A01 (shown on the polaroid caption)
- Photos: add up to 6 per product. Missing frames show a generated plate.

PATTERN NOTES (optional)
Settings > Custom data > Products > Add definition (namespace.key shown):
- custom.year      single line text
- custom.medium    single line text
- custom.lineage   list of single line text   (each line becomes a pattern-note row)

COLLECTIONS / MENUS
- Homepage "Pieces" shows a collection of your choice (blank = all products).
- Header menu defaults to "main-menu", footer menu to "footer".
