/* vaultasampete theme: generated plates + scrubbing stacks + filters */
const PALETTES = [
  {bg:'#FF8FC7', ln:'#2B0F1E', ac:'#FF3E9A', ac2:'#8E9BE0', pa:'#FFF4E6'},
  {bg:'#8E9BE0', ln:'#2B0F1E', ac:'#FF8FC7', ac2:'#F6C98B', pa:'#FFF4E6'},
  {bg:'#F6C98B', ln:'#2B0F1E', ac:'#E0152B', ac2:'#FF8FC7', pa:'#FFF4E6'},
  {bg:'#FF3E9A', ln:'#2B0F1E', ac:'#FFF4E6', ac2:'#8E9BE0', pa:'#F6C98B'},
  {bg:'#FFF4E6', ln:'#2B0F1E', ac:'#FF3E9A', ac2:'#8E9BE0', pa:'#FF8FC7'},
  {bg:'#C9CFF5', ln:'#2B0F1E', ac:'#E0152B', ac2:'#F6C98B', pa:'#FFF4E6'}
];
/* crops of the same scene = different "angles" on the piece */
const CROPS = [
  [0,0,100,120], [22,4,52,62], [0,58,52,62], [48,56,52,62], [28,30,44,53], [6,0,64,77]
];

/* ---------- generated plates (used when a frame has no photo) ---------- */
function rng(a){return function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
function seedOf(s){let h=2166136261;for(const c of s){h^=c.charCodeAt(0);h=Math.imul(h,16777619)}return h>>>0}

const HEART = 'M0 9 C-12 -1 -11 -9 -5 -9 C-2 -9 0 -6 0 -6 C0 -6 2 -9 5 -9 C11 -9 12 -1 0 9Z';
const SPARK = 'M0 -9 Q1.4 -1.4 9 0 Q1.4 1.4 0 9 Q-1.4 1.4 -9 0 Q-1.4 -1.4 0 -9Z';
function sticker(r, pal){
  const kind = r() < .5 ? HEART : SPARK, x = 8 + r()*84, y = 8 + r()*104, k = (.8 + r()*1.1).toFixed(2);
  const fill = [pal.ac, pal.ac2, pal.pa][Math.floor(r()*3)];
  return `<path d="${kind}" transform="translate(${x.toFixed(1)} ${y.toFixed(1)}) scale(${k}) rotate(${(r()*40-20).toFixed(0)})" fill="${fill}" stroke="${pal.ln}" stroke-width=".9"/>`;
}

function scene(p, idx){
  const r = rng(seedOf(p.id)), pal = PALETTES[idx % PALETTES.length], L = pal.ln;
  let s = `<rect width="100" height="120" fill="${pal.bg}"/>`;
  // soft shop-window blocks behind the subject
  s += `<rect x="0" y="${(70+r()*10).toFixed(0)}" width="100" height="50" fill="${pal.ac2}" opacity=".55"/>`;
  s += `<circle cx="${(15+r()*70).toFixed(0)}" cy="${(14+r()*20).toFixed(0)}" r="${(14+r()*10).toFixed(0)}" fill="${pal.pa}" opacity=".7"/>`;

  if(p.kind === 'art'){
    // beaded mirror with an eye inside (original device, echoes the hero)
    const cx = 36 + r()*28, cy = 48 + r()*14;
    s += `<circle cx="${cx.toFixed(1)}" cy="${cy.toFixed(1)}" r="31" fill="${pal.ac}" stroke="${L}" stroke-width="1.4"/>`;
    s += `<circle cx="${cx.toFixed(1)}" cy="${cy.toFixed(1)}" r="26" fill="none" stroke="${pal.pa}" stroke-width="3" stroke-dasharray=".1 5.1" stroke-linecap="round"/>`;
    s += `<circle cx="${cx.toFixed(1)}" cy="${cy.toFixed(1)}" r="21" fill="${pal.ac2}" stroke="${L}" stroke-width="1.2"/>`;
    s += `<path d="M${(cx-17).toFixed(1)} ${cy.toFixed(1)} Q${cx.toFixed(1)} ${(cy-15).toFixed(1)} ${(cx+17).toFixed(1)} ${cy.toFixed(1)} Q${cx.toFixed(1)} ${(cy+15).toFixed(1)} ${(cx-17).toFixed(1)} ${cy.toFixed(1)}Z" fill="${pal.pa}" stroke="${L}" stroke-width="1.1"/>`;
    s += `<circle cx="${cx.toFixed(1)}" cy="${cy.toFixed(1)}" r="7" fill="${pal.ac}" stroke="${L}" stroke-width="1"/><circle cx="${cx.toFixed(1)}" cy="${cy.toFixed(1)}" r="3.4" fill="${L}"/><circle cx="${(cx-1.4).toFixed(1)}" cy="${(cy-1.6).toFixed(1)}" r="1.1" fill="${pal.pa}"/>`;
    s += `<path d="M${(cx-6).toFixed(1)} ${(cy+31).toFixed(1)} L${(cx-8).toFixed(1)} ${(cy+46).toFixed(1)} Q${cx.toFixed(1)} ${(cy+50).toFixed(1)} ${(cx+8).toFixed(1)} ${(cy+46).toFixed(1)} L${(cx+6).toFixed(1)} ${(cy+31).toFixed(1)}Z" fill="${pal.pa}" stroke="${L}" stroke-width="1.2"/>`;
  } else if(p.kind === 'design'){
    // original design: drafted corset front, boning channels, criss-cross lacing, a measurement line
    const d = 'M30 24 Q50 36 70 24 L76 54 Q69 70 76 86 L66 106 L34 106 L24 86 Q31 70 24 54 Z';
    s += `<path d="${d}" fill="${pal.ac}" stroke="${L}" stroke-width="1.4" stroke-linejoin="round"/>`;
    for(let i=0;i<5;i++){ const x = 33 + i*8.5; s += `<line x1="${x}" y1="32" x2="${x}" y2="104" stroke="${L}" stroke-width=".5" stroke-dasharray="2 1.6"/>`; }
    s += `<line x1="50" y1="28" x2="50" y2="105" stroke="${pal.pa}" stroke-width="4.5"/>`;
    for(let i=0;i<7;i++){
      const y = 36 + i*10;
      s += `<circle cx="46.5" cy="${y}" r="1.2" fill="${L}"/><circle cx="53.5" cy="${y}" r="1.2" fill="${L}"/>`;
      if(i < 6) s += `<path d="M46.5 ${y} L53.5 ${y+10} M53.5 ${y} L46.5 ${y+10}" stroke="${L}" stroke-width=".7" fill="none"/>`;
    }
    s += `<path d="M82 24 L82 106 M80 24 h4 M80 106 h4" stroke="${L}" stroke-width=".7" fill="none"/>`;
    s += `<text x="86" y="66" font-size="3.2" font-family="DM Mono, monospace" fill="${L}" transform="rotate(90 86 66)">FRONT / ${1 + Math.floor(r()*3)} OF 3</text>`;
    s += `<circle cx="26" cy="104" r="7" fill="${pal.pa}" stroke="${L}" stroke-width="1"/><text x="26" y="105.6" font-size="4.2" text-anchor="middle" font-family="DM Mono, monospace" fill="${L}">${p.id.slice(3)}</text>`;
  } else {
    // drafted pattern piece: seam allowance, notches, grainline arrow
    const d = 'M34 26 Q50 40 50 26 Q50 40 66 26 L74 60 Q70 80 62 100 L38 100 Q30 80 26 60 Z';
    s += `<path d="${d}" fill="${pal.pa}" stroke="${L}" stroke-width="1.3" stroke-linejoin="round"/>`;
    s += `<path d="${d}" fill="none" stroke="${L}" stroke-width=".6" stroke-dasharray="2.4 1.8" transform="translate(50 63) scale(.88) translate(-50 -63)"/>`;
    s += `<line x1="50" y1="44" x2="50" y2="92" stroke="${L}" stroke-width=".9"/><path d="M50 40 L47.4 46 L52.6 46Z M50 96 L47.4 90 L52.6 90Z" fill="${L}"/>`;
    s += `<path d="M26 60 l-3.4 -1.8 l0 3.6Z M74 60 l3.4 -1.8 l0 3.6Z M50 26 l-1.8 -3.6 l3.6 0Z" fill="${L}"/>`;
    s += `<text x="55" y="66" font-size="3.4" font-family="DM Mono, monospace" fill="${L}">CUT ${1 + Math.floor(r()*3)} ON FOLD</text>`;
    s += `<circle cx="70" cy="104" r="7" fill="${pal.ac}" stroke="${L}" stroke-width="1"/><text x="70" y="105.6" font-size="4.2" text-anchor="middle" font-family="DM Mono, monospace" fill="${L}">${p.id.slice(3)}</text>`;
  }
  for(let i=0;i<4;i++) s += sticker(r, pal);
  return s;
}
function plate(p, idx, f){
  const c = CROPS[f % CROPS.length];
  return `<svg viewBox="${c.join(' ')}" preserveAspectRatio="xMidYMid slice" role="img" aria-label="${p.title}, frame ${f+1}">${scene(p, idx)}</svg>`;
}


/* ---------- theme runtime ---------- */
(function(){
  function hydrate(root){
    (root || document).querySelectorAll('[data-plate]').forEach(function(el){
      if(el.dataset.done) return;
      el.dataset.done = '1';
      el.innerHTML = plate({id: el.dataset.id || 'VS-X00', kind: el.dataset.kind || 'art', title: el.dataset.title || ''},
        parseInt(el.dataset.idx || '0', 10), parseInt(el.dataset.f || '0', 10));
    });
  }
  function stacks(root){
    (root || document).querySelectorAll('.stack').forEach(function(stack){
      if(stack.dataset.ready) return;
      stack.dataset.ready = '1';
      var strip = stack.querySelector('.strip'), counter = stack.querySelector('.counter'), ticks = stack.querySelectorAll('.ticks i');
      if(!strip) return;
      var N = strip.children.length, cur = 0;
      function go(i){
        cur = Math.max(0, Math.min(N - 1, i));
        strip.style.transform = 'translateX(' + (-cur * (100 / N)) + '%)';
        if(counter) counter.textContent = '0' + (cur + 1) + '/0' + N;
        ticks.forEach(function(t, k){ t.classList.toggle('on', k === cur); });
      }
      stack.addEventListener('pointermove', function(e){
        var b = stack.getBoundingClientRect();
        go(Math.floor((e.clientX - b.left) / b.width * N));
      });
      stack.addEventListener('pointerleave', function(){ go(0); });
      stack.addEventListener('keydown', function(e){
        if(e.key === 'ArrowRight'){ e.preventDefault(); go(cur + 1); }
        if(e.key === 'ArrowLeft'){ e.preventDefault(); go(cur - 1); }
      });
      stack.addEventListener('blur', function(){ go(0); });
    });
  }
  function filters(root){
    (root || document).querySelectorAll('.filters').forEach(function(box){
      if(box.dataset.ready) return;
      box.dataset.ready = '1';
      box.querySelectorAll('.chip-btn').forEach(function(b){
        b.addEventListener('click', function(){
          box.querySelectorAll('.chip-btn').forEach(function(x){ x.setAttribute('aria-pressed', String(x === b)); });
          var f = b.dataset.f, scope = box.closest('section') || document;
          scope.querySelectorAll('.piece').forEach(function(pc){ pc.hidden = !(f === 'all' || pc.dataset.kind === f); });
        });
      });
    });
  }
  function eye(){
    var mirror = document.getElementById('eye'), iris = document.getElementById('iris');
    if(!mirror || !iris || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    window.addEventListener('pointermove', function(e){
      var b = mirror.getBoundingClientRect();
      var dx = e.clientX - (b.left + b.width / 2), dy = e.clientY - (b.top + b.height * .47);
      var d = Math.hypot(dx, dy) || 1, m = Math.min(22, d / 12);
      iris.setAttribute('transform', 'translate(' + (dx / d * m).toFixed(1) + ' ' + (dy / d * m * .4).toFixed(1) + ')');
    }, {passive: true});
  }
  function init(root){ hydrate(root); stacks(root); filters(root); }
  init(); eye();
  document.addEventListener('shopify:section:load', function(e){ init(e.target); });
})();
